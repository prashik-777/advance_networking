#include <bits/stdc++.h>
using namespace std;

class Node{
    public:
        int id;
        bool isTransmiting;
        int no_transmits;
        int no_backoffs;
        void Transmit(){
            isTransmiting=false;
        }
};

class Simulator{
    private:
        vector<Node> node;
        int N;
        int c=0;
        int backoff_interval;
        float probability;
        map<int, vector<int> > mp;
        vector<string> log;
    public:
        Simulator(int N,int Time, float p,int bi){
            this->N=N;
            this->probability=p*100;
            this->backoff_interval=bi;
            node.resize(N);
            for(int i=0;i<N;i++){
                node[i].id=i+1;
                node[i].isTransmiting=false;
            }
            simulate(Time);
            Log();
        }
        void randomFire(int Time){
            for(int i=0;i<mp[Time].size();i++){
                node[mp[Time][i]].isTransmiting=true;
                c++;
            }
            for(int i=0;i<N;i++){
                if(!node[i].isTransmiting){
                    if(rand()%100<probability){
                        node[i].isTransmiting=true;
                        c++;
                    }
                }
            }
        }
        void CollisionDetection(int Time){
            if(c>1){
                int i=0;
                for(i=0;i<N;i++){
                    if(node[i].isTransmiting){
                        i++;
                        break;
                    }
                }
                for(i;i<N;i++){
                    if(node[i].isTransmiting){
                        int backoff = rand()%backoff_interval+1;
                        mp[Time+backoff].push_back(i);
                        c--;
                        node[i].no_backoffs++;
                    }
                }
                log.push_back("Collision");
            }
        }
        void CollisionAvoidance(){
            if(c==1){
                for(int i=0;i<N;i++){
                    if(node[i].isTransmiting){
                        node[i].Transmit();
                        node[i].no_transmits++;
                    }
                }
                c--;
                log.push_back("Success");
            }
            else if(c==0){
                log.push_back("Empty");
            }
        }
        void simulate(int Time){
            for(int i=0;i<Time;i++){
                randomFire(i);
                CollisionDetection(i);
                CollisionAvoidance();
            }
        }
        void Log(){
            for(int i=0;i<log.size();i++){
                cout<<log[i]<<", ";
            }
            cout<<endl;
            for(int i=0;i<N;i++){
                printf("Node-%d transmitted %d times, had to backoff %d times\n", node[i].id, node[i].no_transmits, node[i].no_backoffs);
            }
        }
        ~Simulator(){
            node.clear();
            mp.clear();
            log.clear();
        }
};

int main(){
    Simulator Simulator1(5, 100, 0.01, 5);     // Less Devices, Less Traffic
    Simulator Simulator2(5, 100, 0.10, 5);    // Less Devices, More Traffic
    Simulator Simulator3(10, 100, 0.01, 5);  // More Devices, Less Traffic
    Simulator Simulator4(10, 100, 0.1, 5);  // More Devices, More Traffic
    return 0;
}