#include <iostream>
#include <queue>
#include <random>
#include <thread>
#include <chrono>
#include <mutex>
#include <vector>
using namespace std;

const int SimulationTimeInMinutes = 100; // Total simulation time in minutes

// Function to generate random exponential service times
default_random_engine arrival,service;



exponential_distribution<double> arr(4.0),ser(5.0);
vector<double> v;
double sum=0;
double generateArrivalTime(double lambda) {
    random_device rd;
    mt19937 gen(rd());
    exponential_distribution<double> exponential(lambda);
    return exponential(gen);
}

double generateServiceTime(double lambda) {
    random_device rd;
    mt19937 gen(rd());
    exponential_distribution<double> exponential(lambda);
    return exponential(gen);
}
// Function for passenger arrival and queuing
void passengerArrivalAndQueuing(double lambda, double mu, int K, vector<queue<double>>& q, vector<int>& totalPassengers, vector<mutex>& passengersMutex,mutex& outputMutex) {
    double currentTime = 0.0;
    int i = 0;
    int S = q.size();
    while (currentTime < SimulationTimeInMinutes) {
        // Generate inter-arrival time
        // Check if passengers can enter the buffer or have to wait
        int idx = rand()%S;
        if (q[idx].size() >= K) continue;
        double interArrivalTime = generateArrivalTime(lambda);
        passengersMutex[idx].lock();
        i++;
        // Update current time
        currentTime += interArrivalTime;
        q[idx].push(currentTime); // Passengers enter the buffer
        // Update totalPassengers with mutex protection
        totalPassengers[idx]++;
        passengersMutex[idx].unlock();
        outputMutex.lock();
        cout << "time of " << i << " = " << currentTime << endl;
        outputMutex.unlock();
       
    }
    for(int i = 0; i < S; i++){
        passengersMutex[i].lock();
        q[i].push(currentTime);
        passengersMutex[i].unlock();
    }
}

// Function for passenger servicing
void passengerServicing(int scanner, double mu, vector<queue<double>>& queue, vector<double>& totalTimeInSystem,vector<double>& totalTimeWaitingInQueue,vector<mutex>& passengersMutex, mutex& outputMutex, vector<mutex>& timeMutex,vector<double>& totalServiceTime){
    double currentTime = 0;
    int i = 1;
    while (true) {        
        passengersMutex[scanner].lock();
        if (!queue[scanner].empty()) {      
            double arrivalTime = queue[scanner].front();
            if(arrivalTime > SimulationTimeInMinutes){
                passengersMutex[scanner].unlock();
                break;
            }
            queue[scanner].pop();
            passengersMutex[scanner].unlock();
            if(arrivalTime > currentTime){
                currentTime = arrivalTime;
            }

            double serviceTime = generateServiceTime(mu);
            currentTime += serviceTime;
            timeMutex[scanner].lock();
            totalTimeWaitingInQueue[scanner] += (currentTime - arrivalTime - serviceTime);
            totalTimeInSystem[scanner] += currentTime - arrivalTime;
            totalServiceTime[scanner] += serviceTime;
            timeMutex[scanner].unlock();
            outputMutex.lock();
            int cnt = 0;
            cout << scanner << "servicetime of " << i << " = " << serviceTime << endl;
            cout << scanner << "currenttime of " << i << " = " << currentTime << endl;
            cout << scanner << "TotalTimeinQueue of " << i << " = " << totalTimeInSystem[scanner] << endl;
            outputMutex.unlock();
            i++;          
        }
        else{
            passengersMutex[scanner].unlock();
        }
    }
}

int main() {
    double lambda; // Arrival rate (passengers per unit of time)
    double mu;     // Service rate (passengers processed per unit of time)
    int K;         // Buffer size
    int S;
    cout << "Enter arrival rate (lambda): ";
    cin >> lambda;
    cout << "Enter service rate (mu): ";
    cin >> mu;
    cout << "Enter buffer size (K): ";
    cin >> K;
    cout << "Enter number of scanners: ";
    cin >> S;
    cout << "Hello" ;

    arrival.seed(time(NULL));
    service.seed(time(NULL));

    arr = exponential_distribution<double>(lambda);
    ser = exponential_distribution<double>(mu);


    vector<queue<double>> q(S); // vector of queues to hold passengers 
    vector<double> totalTimeInSystem(S, 0.0);
    vector<double> totalTimeWaitingInQueue(S, 0.0);
    vector<double> totalServiceTime(S, 0.0);
    vector<int>  totalPassengers(S,0);
    vector<mutex> passengersMutex(S); // Mutex for totalPassengers
    mutex outputMutex; // Mutex for thread-safe output
    vector<mutex> timeMutex(S); // Mutex for thread-safe output
    
    
    // // Threads for passenger arrival/queuing and servicing
    thread arrivalThread(passengerArrivalAndQueuing, lambda, mu, K, ref(q),  ref(totalPassengers), ref(passengersMutex), ref(outputMutex));
    vector<thread> temp;
    for(int i = 0; i < S; i++){
        temp.push_back(thread (passengerServicing, i, mu, ref(q), ref(totalTimeInSystem),ref(totalTimeWaitingInQueue),ref(passengersMutex), ref(outputMutex),ref(timeMutex),ref(totalServiceTime)));
    }


    arrivalThread.join();
    for(thread& thread: temp){
        thread.join();
    }
    // Calculate and report statistics with output mutex protection

    for(int i = 0; i < S; i++)  
    {   
        cout << endl;
        cout<< "SCANNER " << i << endl;
        lock_guard<mutex> lock1(outputMutex);
        lock_guard<mutex> lock2(timeMutex[i]);
        cout << "total passengers: " << totalPassengers[i] << endl;
        cout << "Average System Time: " << totalTimeInSystem[i] / (totalPassengers[i]-1) << " minutes" << endl;
        cout << "Average Waiting Time: " << totalTimeWaitingInQueue[i] / (totalPassengers[i]-1) << " minutes" << endl;
        cout << "Average Queue Length: " << totalTimeInSystem[i] / SimulationTimeInMinutes << " passengers/minute" << endl;
        cout << "System Utilization: " << (totalServiceTime[i]/ SimulationTimeInMinutes) * 100 << "%" << endl;
    }

    return 0;
}